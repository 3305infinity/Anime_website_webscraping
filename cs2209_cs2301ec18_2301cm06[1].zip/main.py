import requests
from bs4 import BeautifulSoup
import json
import csv
from fpdf import FPDF

def fetch_and_save_data(url, path):
    r = requests.get(url)
    if r.status_code == 200:
        with open(path, 'w', encoding='utf-8') as f:
            f.write(r.text)
    else:
        print(f"Failed to fetch data. HTTP Status Code: {r.status_code}")

# URL and file path
url = "https://myanimelist.net/topanime.php"
file_path = "data.html"

# Fetch and save data
fetch_and_save_data(url, file_path)

# Parse the saved HTML
with open(file_path, 'r', encoding='utf-8') as f:
    soup = BeautifulSoup(f, 'html.parser')

# Initialize the anime data list
anime_data = []

# Extract anime details
anime_divs = soup.find_all("div", class_="detail")
score_divs = soup.find_all("div", class_="js-top-ranking-score-col")

for anime, score_div in zip(anime_divs, score_divs):
    name = anime.find("h3", class_="anime_ranking_h3").text.strip()  # Anime name
    information = anime.find("div", class_="information").text.split("\n")
    
    episodes = information[1].strip()  # Episodes
    date_range = information[2].strip()  # Air dates
    members = information[3].strip()  # Members count
    
    score = score_div.find("span", class_="score-label").text.strip()  # Score
    
    # Append data as a dictionary
    anime_data.append({
        'Name': name,
        'Episodes': episodes,
        'Air Dates': date_range,
        'Members': members,
        'Score': score
    })


# Save to a PDF file
pdf_file = "anime_data.pdf"
pdf = FPDF()
pdf.set_auto_page_break(auto=True, margin=15)
pdf.add_page()

# Set smaller font size to fit data
pdf.set_font("Arial", size=5)  # Reduced font size for better fitting

pdf.cell(200, 10, txt="Anime Data", ln=True, align='C')
pdf.ln(10)

# Define column widths
col_widths = [50, 25, 50, 25, 20]  # Adjust column widths accordingly

# Table Header
pdf.cell(col_widths[0], 10, 'Name', border=1, align='C')
pdf.cell(col_widths[1], 10, 'Episodes', border=1, align='C')
pdf.cell(col_widths[2], 10, 'Air Dates', border=1, align='C')
pdf.cell(col_widths[3], 10, 'Members', border=1, align='C')
pdf.cell(col_widths[4], 10, 'Score', border=1, align='C')
pdf.ln()

# Table rows
for anime in anime_data:
    pdf.cell(col_widths[0], 10, anime['Name'], border=1)
    pdf.cell(col_widths[1], 10, anime['Episodes'], border=1, align='C')
    pdf.cell(col_widths[2], 10, anime['Air Dates'], border=1, align='C')
    pdf.cell(col_widths[3], 10, anime['Members'], border=1, align='C')
    pdf.cell(col_widths[4], 10, anime['Score'], border=1, align='C')
    pdf.ln()

pdf.output(pdf_file)
print(f"Data has been saved in PDF format to '{pdf_file}'")



# Save to a TXT file
txt_file = "anime_data.txt"
with open(txt_file, 'w', encoding='utf-8') as f:
    for anime in anime_data:
        f.write(f"Name: {anime['Name']}\n")
        f.write(f"Episodes: {anime['Episodes']}\n")
        f.write(f"Air Dates: {anime['Air Dates']}\n")
        f.write(f"Members: {anime['Members']}\n")
        f.write(f"Score: {anime['Score']}\n\n")

print(f"Data has been saved in TXT format to '{txt_file}'")

# Save to a CSV file (BONUS TASK)
csv_file = "anime_data.csv"
with open(csv_file, 'w', newline='', encoding='utf-8') as f:
    writer = csv.DictWriter(f, fieldnames=['Name', 'Episodes', 'Air Dates', 'Members', 'Score'])
    writer.writeheader()
    writer.writerows(anime_data)

print(f"Data has been saved in CSV format to '{csv_file}'")


# Save to a JSON file (BONUS TASK)
json_file = "anime_data_tabular.json"
with open(json_file, 'w', encoding='utf-8') as f:
    json.dump(anime_data, f, ensure_ascii=False, indent=4)

print(f"Data has been saved in JSON format to '{json_file}'")

# Print the stored anime details
print(f"{'Name':<40} {'Episodes':<15} {'Air Dates':<25} {'Members':<15} {'Score':<5}")
print("-" * 110)

# Loop through the anime_data list to print each anime's details
for anime in anime_data:
    print(f"{anime['Name']:<40} {anime['Episodes']:<15} {anime['Air Dates']:<25} {anime['Members']:<15} {anime['Score']:<5}")